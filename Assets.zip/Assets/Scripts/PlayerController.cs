﻿using UnityEngine;
using System.Collections;

public class PlayerController : MonoBehaviour {

    // Public variables
    public float speed;
    public float speedRotate;
    public float gravity;
    public float force;

    // Private Variables
    private CharacterController controller;
    private Vector3 moveDirection;
    private float deltaTime;

	// Use this for initialization
	void Start () {
        controller = GetComponent<CharacterController>();
	}
	
	// Update is called once per frame
	void Update () {

        // Cadence du temps
        deltaTime = Time.deltaTime;

        // Déplacements Haut/Bas
        if (Input.GetKey(KeyCode.LeftShift))
        {
            moveDirection = new Vector3(0, 0, Input.GetAxis("Vertical") * speed * 2);
        }
        else moveDirection = new Vector3(0, 0, Input.GetAxis("Vertical") * speed);

        moveDirection = transform.TransformDirection(moveDirection);

        // Rotation du personnage
        transform.Rotate(new Vector3(0, Input.GetAxis("Horizontal") * speedRotate * deltaTime, 0));

        // Gravité
        moveDirection.y -= gravity;

        // Déplacement du Character Controller
        controller.Move(moveDirection * deltaTime);
	}

    // Intéractions avec le Block
    void OnTriggerEnter(Collider other)
    {
        // Afficher "Push ! (F)"
        other.GetComponentInParent<Rigidbody>().isKinematic = false;
    }

    // Déplacement du Block
    void OnTriggerStay(Collider other)
    { 
        if (other.gameObject.tag == "Back" && Input.GetKey(KeyCode.F))
        {
            other.GetComponentInParent<Rigidbody>().AddForce(Vector3.forward * force);            
        }

        if (other.gameObject.tag == "Face" && Input.GetKey(KeyCode.F))
        {
            other.GetComponentInParent<Rigidbody>().AddForce(Vector3.back * force);
        }

        if (other.gameObject.tag == "Left" && Input.GetKey(KeyCode.F))
        {
            other.GetComponentInParent<Rigidbody>().AddForce(Vector3.right * force);
        }

        if (other.gameObject.tag == "Right" && Input.GetKey(KeyCode.F))
        {
            other.GetComponentInParent<Rigidbody>().AddForce(Vector3.left * force);
        }
        
    }

    void OnTriggerExit(Collider other)
    {
        // Effacer le texte
    }
}
