﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class Recolte : MonoBehaviour {

    // Public variables
    public float speed;
    public float speedRotate;
    public float gravity;
    public float force;
    public float timer;
    public Text countText;
    public Text winText;
    public Text timerText;

    // Private Variables
    private CharacterController controller;
    private Vector3 moveDirection;
    private float deltaTime;
    private int count;

    // Use this for initialization
    void Start () {
        controller = GetComponent<CharacterController>();
        count = 0;
        SetCountText();
        winText.text = "";
    }
	
	// Update is called once per frame
	void Update () {
        // Cadence du temps
        deltaTime = Time.deltaTime;

        // Déplacements Haut/Bas
        if (Input.GetKey(KeyCode.LeftShift))
        {
            moveDirection = new Vector3(0, 0, Input.GetAxis("Vertical") * speed * 2);
        }
        else moveDirection = new Vector3(0, 0, Input.GetAxis("Vertical") * speed);

        moveDirection = transform.TransformDirection(moveDirection);

        // Rotation du personnage
        transform.Rotate(new Vector3(0, Input.GetAxis("Horizontal") * speedRotate * deltaTime, 0));

        // Gravité
        moveDirection.y -= gravity;

        // Déplacement du Character Controller
        controller.Move(moveDirection * deltaTime);

        // Décompte du Timer
        timer -= deltaTime;
        timerText.text = "Temps: " + timer.ToString();
        if (timer <= 0)
        {
            // Game Over
            timer = 0;
        }
    }

    void OnTriggerEnter(Collider other)
    {
        // Ajout de l'élément au compteur et désactivation
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count += 1;
            SetCountText();
        }
    }

    void SetCountText()
    {
        // Affichage du texte
        countText.text = "Count: " + count.ToString();
        if (count >= 5)
        {
            winText.text = "You Win !!";
        }
    }
}

    


