﻿using UnityEngine;
using System.Collections;

public class OpenTheGate : MonoBehaviour {

    public Collider Door;

    private bool IsTouched;

	// Update is called once per frame
	void Update () {

        // La porte se referme si rien est en contact avec l'interrupteur
        if (Door.transform.position.x >= 0 && !IsTouched)
        {
            Door.transform.position -= new Vector3(10, 0, 0) * Time.deltaTime;
        }
    }

    void FixedUpdate()
    {
        // Pour éviter des problèmes d'affichages...
        IsTouched = false;
    }

    // La porte s'ouvre si un block entre en contact avec l'interrupteur
    void OnTriggerStay(Collider other)
    {
        IsTouched = true;

        if (Door.transform.position.x <= 25.5)
        {
            Door.transform.position += new Vector3(5, 0, 0) * Time.deltaTime;
        }
    }
}
