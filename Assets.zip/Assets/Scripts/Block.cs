﻿using UnityEngine;
using System.Collections;

public class Block : MonoBehaviour {
	
	// Update is called once per frame
	void Update () {
	    
        // Immobilisation du Block
        if (GetComponent<Rigidbody>().IsSleeping())
        {
            GetComponent<Rigidbody>().isKinematic = true;
        }
	}
}
